
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

public class NappaimistonKuuntelija implements KeyListener {

    private Pelihahmo pelihahmo;

    public NappaimistonKuuntelija(Pelihahmo pelihahmo) {
        this.pelihahmo = pelihahmo;
    }

    @Override
    public void keyTyped(KeyEvent e) {
        // ei koodia
    }

    @Override
    public void keyPressed(KeyEvent e) {
        if (e.getKeyCode() == KeyEvent.VK_SPACE) {
            pelihahmo.hyppaa();
        }
    }

    @Override
    public void keyReleased(KeyEvent e) {
        // ei koodia
    }
}
