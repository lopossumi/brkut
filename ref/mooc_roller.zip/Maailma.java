
import java.util.ArrayList;

public class Maailma {
    // lisää tänne muuttuja "kierros", jonka avulla voidaan pitää kirjaa
    // kierroksista
    private int kierros;
    
    private int painovoima;
    private int nopeus;
    private ArrayList<Alusta> alustat;
    private Pelihahmo pelihahmo;
    
    public Maailma() {
        // alusta täällä muuttujan kierros arvoksi 0
        this.kierros = 0;
        
        this.painovoima = 1;
        this.nopeus = 1;
        
        // älä muuta alustojen luontia
        this.alustat = new ArrayList<Alusta>();
        this.alustat.add(new Alusta(0, 300, 300, 30));
        this.alustat.add(new Alusta(320, 340, 250, 30));
        this.alustat.add(new Alusta(595, 310, 220, 30));
        this.alustat.add(new Alusta(850, 280, 100, 30));
        // voit lisätä toki omia alustoja halutessasi!

        this.pelihahmo = new Pelihahmo(70, 30, 10);
    }

    public void nopeuta() {
        this.nopeus = nopeus + 1;
    }

    public void liikuta() {
        for (Alusta alusta : alustat) {
            alusta.liiku(nopeus);
        }
        
        this.pelihahmo.liiku(painovoima);
        
        // asetetaan hahmo alustalle jos mahdollista
        for (Alusta alusta : alustat) {
            this.pelihahmo.yritaKayttaaAlustaa(alusta);
        }
        
        // siirretään alustoja uudestaan oikealle
        for (Alusta alusta : alustat) {
            if(alusta.getX() + alusta.getLeveys() < 0) {
                alusta.setX(alusta.getX() + 1000);
            }
        }
        
        // nopeutetaan peliä 600 kierroksen välein (600 kierrosta on noin 
        // 10 sekuntia)
        this.kierros = this.kierros + 1;
        if(kierros % 600 == 0) {
            nopeuta();
        }
    }
    
    public ArrayList<Alusta> getAlustat() {
        return alustat;
    }
    
    public Pelihahmo getPelihahmo() {
        return pelihahmo;
    }

    public int getNopeus() {
        return nopeus;
    }
}
