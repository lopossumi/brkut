

public class Pelihahmo {
    private int x;
    private int y;
    
    private int halkaisija;
    
    private int liikeY;

    public Pelihahmo(int x, int y, int halkaisija) {
        this.x = x;
        this.y = y;
        this.halkaisija = halkaisija;
        
        this.liikeY = 0;
    }

    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }

    public int getHalkaisija() {
        return halkaisija;
    }

    public void liiku(int painovoima) {
        this.y = this.y - this.liikeY;
        this.liikeY = this.liikeY - painovoima;
        
        if(this.liikeY < -8) {
            this.liikeY = -8;
        }
    }
    
    public void yritaKayttaaAlustaa(Alusta alusta) {
        if(this.x < alusta.getX()) {
            return;
        }
        
        if(this.x > alusta.getX() + alusta.getLeveys()) {
            return;
        }
        
        if(this.y + this.halkaisija < alusta.getY()) {
            return;
        }
        
        if(this.y > alusta.getY() + alusta.getKorkeus()) {
            return;
        }
        
        this.y = alusta.getY() - this.halkaisija;
        this.liikeY = 0;
    }
    
    public void hyppaa() {
        if(liikeY != 0) {
            return;
        }
        
        liikeY = 16;        
    }

    public int getLiikeY() {
        return liikeY;
    }
}
