
import java.awt.Color;
import java.awt.Graphics;
import java.util.ArrayList;
import javax.swing.JPanel;

public class Ikkuna extends JPanel {

    private Maailma maailma;

    public Ikkuna(Maailma maailma) {
        this.maailma = maailma;
    }

    @Override
    public void paint(Graphics g) {
        super.paint(g);

        g.setColor(Color.RED);

        ArrayList<Alusta> alustat = maailma.getAlustat();
        for (Alusta alusta : alustat) {
            g.drawRect(alusta.getX(), alusta.getY(), alusta.getLeveys(), alusta.getKorkeus());
        }
        
        g.setColor(Color.BLACK);
        
        Pelihahmo hahmo = maailma.getPelihahmo();
        g.fillOval(hahmo.getX(), hahmo.getY(), hahmo.getHalkaisija(), hahmo.getHalkaisija());

        // kutsu getToolkit().sync() varmistaa että jokainen piirtokutsu
        // hoidetaan heti
        getToolkit().sync();
    }
}
